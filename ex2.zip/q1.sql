select distinct m.name
from members m
where birthYear>1970
order by m.name;
